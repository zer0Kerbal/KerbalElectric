# ModuleKELights :: Change Log

* 2018-0824: 0.1.0.5 Beta (Lisias) for KSP 1.4.x
	+ Preventing NullReferences on the FixedUpdated. 
* 2018-0624: 0.0.3 Beta (Fengist) for KSP 1.4.x
	+ Update for KSP 1.4.x
	+ Includes 3 new 'SLIME' lights. Now your Kerbal can look just like a Top Gun graduate (Flattop haircut optional)
* 2017-0930: 0.0.2 Beta (Fengist) for KSP 1.3.1
	+ No changelog available

No further data availale.

